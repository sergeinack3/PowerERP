<style>


    /* index page  */

    #grid_title{ 
        text-align: center;
    }

    #grid_title title_name{ 
        width:50px;
        font-size:18px
    }

    #grid_title description_name{
        font-size:18px
    }

    #id-container #id-right { 
        background-image: url("img/object_background-1.jpg");
        background-position: center left;
        background-repeat : no-repeat;
        overflow-x: hidden;
        margin : 0; 
        opacity ; 0.5; 
        min-width: 60%; 
        width : 100%;
        height : 86%; 
        position : absolute; 
    }
    body {  overflow-x: hidden; }

    @media (min-width: 1400px) {
        img {
            width: 100%;
        }
        #id-container #id-right { 
            background-image: url("img/object_background-2.jpeg");
            background-position: center left;
            background-repeat : no-repeat;
            overflow-x: hidden;
            margin : 0;
            opacity ; 0.5; 
            min-width: 60%; 
            width : 100%;
            height : 91%; 
            position : absolute; 
        }
    }

    /* Documents pages */

    








</style>