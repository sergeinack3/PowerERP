# CHANGELOG STATION FOR [DOLIBARR ERP CRM](https://www.powererp.org)

## 1.0

Initial version
