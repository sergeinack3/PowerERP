# EMPRUNT FOR [DOLIBARR]

## Desvription 

This module allows employees to borrow within a company from a PowerERP instance.

Create commitment types and generate loans specific to your needs

This module requires a stable installation of PowerERP >=8.0.0.

Thank you for your contribution

## Contact

Description of the module...



Other external modules are available on [Dolistore.com](https://www.dolistore.com).

Contact
This module is developped by PowerERP (https://powererp.site)

Website: https://ipowerworld.net

Development platform: git.framasoft.org/inodbox/multicompany/

Uses Michel Fortin's PHP Markdown Licensed under BSD to display this README.

### Main code

GPLv3 or (at your option) any later version. See file COPYING for more information.

### Documentation

All texts and readmes are licensed under GFDL.
