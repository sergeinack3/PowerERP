# CHANGELOG EMPRUNT FOR [DOLIBARR ERP CRM](https://powerep.site)

## 1.3

Initial version
