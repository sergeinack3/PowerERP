<?php
/* Copyright (C) 2014-2018  Alexandre Spangaro      <aspangaro@open-dsi.fr>
 * Copyright (C) 2015-2018  Frédéric France         <frederic.france@netlogic.fr>
 * Copyright (C) 2020       Maxime DEMAREST         <maxime@indelog.fr>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

/**
 *	    \file       htdocs/emprunt/payment/payment.php
 *		\ingroup    emprunt
 *		\brief      Page to add payment of a emprunt
 */

require '../../../main.inc.php';
require_once DOL_DOCUMENT_ROOT.'/core/class/html.formcompany.class.php';
dol_include_once('/immobilisations/class/immobilisations.class.php');
dol_include_once('/immobilisations/class/Categories.class.php');
dol_include_once('/immobilisations/lib/immobilisations_immobilisations.lib.php');

$langs->loadLangs(array("bills", "emprunt"));

$id = GETPOST('id', 'int');
$action = GETPOST('action', 'aZ09');
$cancel = GETPOST('cancel', 'alpha');
$datepaid = dol_mktime(12, 0, 0, GETPOST('remonth', 'int'), GETPOST('reday', 'int'), GETPOST('reyear', 'int'));

// Security check
$socid = 0;
if ($user->socid > 0) {
	$socid = $user->socid;
} elseif (GETPOSTISSET('socid')) {
	$socid = GETPOST('socid', 'int');
}
if ($permissiontoadd) {
	accessforbidden();
}


$object = new Immobilisations($db);
$object_categories = new Categories($db);


/*
 * View
 */

llxHeader();

$form = new Form($db);



$head = immobilisationsPrepareHead($object);

print dol_get_fiche_head($head, 'depreciation', $langs->trans("Immobilisations"), -1, $object->picto);

dol_banner_tab($object, 'ref', $linkback, 1, 'ref', 'ref', $morehtmlref, '', 0, '', '', 1);

	
		



		
print dol_get_fiche_end();

		



llxFooter();
$db->close();
