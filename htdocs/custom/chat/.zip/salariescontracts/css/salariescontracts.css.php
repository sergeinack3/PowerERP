<?php

header("Content-Type: text/css");