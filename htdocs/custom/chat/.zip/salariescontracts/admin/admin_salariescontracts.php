<?php 

echo 'Im salariescontracts module config page';

?>