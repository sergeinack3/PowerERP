-- <Dolibase logs table>
-- Copyright (C) <2018>  <AXeL>

ALTER TABLE llx_dolibase_logs ADD object_element VARCHAR(100) DEFAULT NULL;
