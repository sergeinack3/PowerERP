﻿CREATE TABLE IF NOT EXISTS `llx_ecv` (
  `rowid` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `ref` varchar(50) NOT NULL
);