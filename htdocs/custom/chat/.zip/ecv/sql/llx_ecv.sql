﻿CREATE TABLE IF NOT EXISTS `llx_ecv` (
  `rowid` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `ref` varchar(50) NOT NULL
  `label` varchar(50) NOT NULL
  `debut` dateTime() NOT NULL
  `fin` dateTime() NOT NULL
  `note` int() NOT NULL
);